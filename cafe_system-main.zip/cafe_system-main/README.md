# <img src="https://i.imgur.com/4sklkeQ.png" height="30px">  Cafe Project
Simple OOP PHP cafe managment system for ITI Internship


**Languages and Technologies:**  

<code><img height="24" src="https://cdn.cdnlogo.com/logos/h/90/html-5.svg"></code>
<code><img height="20" src="https://cdn.cdnlogo.com/logos/c/18/css.svg"></code>
<code><img height="20" src="https://cdn.cdnlogo.com/logos/b/50/bootstrap.svg"></code>
<code><img height="20" src="https://cdn.cdnlogo.com/logos/p/71/php.svg"></code>
<code><img height="26" src="https://cdn.cdnlogo.com/logos/m/47/mysql.svg"></code>
<code><img height="24" src="https://cdn.cdnlogo.com/logos/f/80/fontawesome.svg"></code>
<code><img height="24" src="https://cdn.cdnlogo.com/logos/g/35/google-icon.svg"></code>


**ScreenShoots:**  

<img src="https://i.imgur.com/nJEoh5L.jpg" width="300px"> 

<img src="https://i.imgur.com/VWn23nt.jpg" width="300px"> 

<img src="https://i.imgur.com/Ypdr5Ot.jpg" width="300px"> 

**Run The Apllication:**  

```

1- Install XAMPP or WAMPP.

2- Download project from github https://github.com/mina-isaac-99/php_cafe_system

3- open link localhost/phpmyadmin 
4- create database with name cafe_system. 

5- import database file from project folder.

6- open any browser and type  http://localhost/cafe-system/ 

7- En(:oy 

```

**Login Details:**  

**Admin:

username : admin@admin.com 
password : 12345 

**User Details: 

username : user@user.com 
password : 12345 
