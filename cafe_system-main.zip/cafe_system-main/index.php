<?php
header('location:Views')
?>